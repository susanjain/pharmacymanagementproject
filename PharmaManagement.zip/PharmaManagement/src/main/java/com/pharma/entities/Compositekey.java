package com.pharma.entities;

import java.io.Serializable;

public class Compositekey implements Serializable {
    private int id;
    private String medName;
    private String manufacComp;
}